--[[
	RobloxPlayerScript - This script loads the CameraScript and ControlScript modules
	
	2018 PlayerScripts Update - AllYourBlox	
--]]
local CameraScript = require(script:WaitForChild("CameraScript"))
local ControlScript = require(script:WaitForChild("ControlScript"))